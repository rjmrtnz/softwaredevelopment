﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace UpdateEmployee
{
    public partial class UpdateEmployee21 : System.Web.UI.Page
    {
        private SqlCommand cmd;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Session from UpdateEmployee page
            int session = (Int32)Session["employee"];
            txtEmployeeID.Text = Convert.ToString(session);
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
        }
        public void ClearTextBoxes()
        {
            txtEmployeeID.Text = string.Empty;
            txtFirstName.Text = string.Empty;
            txtLastName.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtContactNumber.Text = string.Empty;
            txtEmail.Text = string.Empty;
            ddlTitle.SelectedIndex = -1;
            ddlStatus.SelectedIndex = -1;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            // Setting up sql connection
            string cs = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;

            using (SqlConnection con = new SqlConnection(cs))
            {
                int employeeID = Convert.ToInt32(txtEmployeeID.Text);
                //cmd = new SqlCommand("update Employee set FirstName=@firstName, LastName=@lastName, Address=@address, PhoneNum=@phoneNum, Email=@email, Title=@title, active=@active where EmployeeID = '" + Convert.ToInt32(txtEmployeeID.Text) + "'", con);
                //cmd.Parameters.AddWithValue("firstName", txtFirstName.Text);
                //cmd.Parameters.AddWithValue("lastName", txtLastName.Text);
                //cmd.Parameters.AddWithValue("address", txtAddress.Text);
                //cmd.Parameters.AddWithValue("phoneNum", txtContactNumber.Text);
                //cmd.Parameters.AddWithValue("email", txtEmail.Text);
                //cmd.Parameters.AddWithValue("title", ddlTitle.SelectedIndex);
                //cmd.Parameters.AddWithValue("active", ddlStatus.SelectedIndex);
                //cmd.ExecuteNonQuery();

                // CHANGE DDL if null because its not string
                // Updates only if the parameter is not null or empty
                using (SqlCommand cmd = new SqlCommand("update Employee set FirstName = IsNull(NullIf(@firstName, ''), FirstName), LastName = IsNull(NullIf(@lastName, ''), LastName), Address = IsNull(NullIf(@address, ''), Address), " +
                    "PhoneNum = IsNull(NullIf(@phoneNum, ''), PhoneNum), Email = IsNull(NullIf(@email, ''), Email), Title = IsNull(NullIf(@title, ''), Title), active = IsNull(NullIf(@active, ''), active) where EmployeeID = '" + Convert.ToInt32(txtEmployeeID.Text) + "'", con))
                {
                    cmd.Parameters.AddWithValue("firstName", txtFirstName.Text);
                    cmd.Parameters.AddWithValue("lastName", txtLastName.Text);
                    cmd.Parameters.AddWithValue("address", txtAddress.Text);
                    cmd.Parameters.AddWithValue("phoneNum", txtContactNumber.Text);
                    cmd.Parameters.AddWithValue("email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("title", ddlTitle.SelectedIndex);
                    cmd.Parameters.AddWithValue("active", ddlStatus.SelectedIndex);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}