﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace UpdateEmployee
{
    public partial class UpdateEmployee1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
        }

        public void ClearTextBoxes()
        {
            txtEmployeeID.Text = string.Empty;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            // Setting up sql connection
            string cs = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;

            // Check if there is no user input
            if (txtEmployeeID.Text == "")
            {
                lblResponse.Visible = true;
                lblResponse.ForeColor = System.Drawing.Color.IndianRed;
                lblResponse.Text = "Please enter the ID of the employee whose details you are editing.";
            }
            else
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();
                    int employeeID = Convert.ToInt32(txtEmployeeID.Text);
                    string query = "select * from Employee where EmployeeID = '" + Convert.ToInt32(txtEmployeeID.Text) + "'";
                    SqlCommand cmd = new SqlCommand(query, con);

                    // Checks if there is record
                    string output = cmd.ExecuteScalar().ToString();

                    // Check if employee ID exists in database
                    if (output == "1")
                    {
                        // Setting up a session
                        Session["employee"] = employeeID;

                        // Proceed to redirect to Update Page
                        Response.Redirect("UpdateEmployee2.aspx");
                    }
                    else
                    {
                        lblResponse.Text = "Employee cannot be found.";
                    }
                }
            }
        }
    }
}
